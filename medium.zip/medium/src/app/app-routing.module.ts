import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from './main/main.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { MembershipComponent } from './membership/membership.component';
import { WriteComponent } from './write/write.component';
import { OurStoryComponent } from './our-story/our-story.component';
import { AppComponent } from './app.component';
import { GetStartedComponent } from './get-started/get-started.component';

const routes: Routes = [{ path: '', component: AppComponent }, 
{ path: 'get-started', component: GetStartedComponent },
{ path: 'signin', component: SignInComponent }, 
{ path: 'membership', component: MembershipComponent }, 
{ path: 'write', component: WriteComponent },
{ path: 'our-story', component: OurStoryComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
