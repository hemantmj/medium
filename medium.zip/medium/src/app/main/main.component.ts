import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  array=[{name:"Our story",link:"/our-story"},{name:"Membership",link:"/membership"},{name:"Write",link:"/write"},{name:"Sign In",link:"/signin"},{name:"Get started",link:"/get-started"}]

  constructor() { }

  ngOnInit(): void {
  }

}
